package com.tqi.analisecredito.webfinancasbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfinancasbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfinancasbackendApplication.class, args);
	}

}
