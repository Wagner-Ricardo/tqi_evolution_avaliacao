package com.tqi.analisecredito.webfinancasbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfinancasbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
